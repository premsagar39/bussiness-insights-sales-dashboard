# Editable Power BI source

Open the .pbip file in Power BI Desktop, select Refresh if prompted, and save a PBIX copy through File > Save as. The report contains three visible pages plus hidden tooltip and drill-through pages.

The model imports compressed CSV snapshots embedded in Power Query. No database account or local data path is required. The data/ folder provides the same prepared rows for review and SQL checks.

To change the source snapshot, close Power BI, install requirements.txt, and run:

    python refresh_snapshot.py --source "path/to/source.csv" --project .

Reopen the PBIP and select Refresh. Use the compact-column SuperStoreUS-2015 CSV for Superstore or the original Diwali CSV for Diwali. The script preserves DAX measures and report definitions while updating prepared data and embedded query snapshots.

analysis.sql uses SQLite syntax and operates on a sales table populated from data/sales.csv. Existing MySQL scripts in the Superstore GitHub repository are separate from these reconciliation queries.
