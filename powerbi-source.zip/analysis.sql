-- SQLite reconciliation against prepared sales.csv.
-- Load sales.csv into a table named sales first.

SELECT COUNT(*) records,SUM(Sales) sales,SUM(Profit) profit,COUNT(DISTINCT OrderID) orders,AVG(julianday(ShipDate)-julianday(OrderDate)) avg_days FROM sales;

SELECT ProductCategory category,SUM(Sales) sales,SUM(Profit) profit FROM sales GROUP BY 1 ORDER BY sales DESC;

SELECT Region,SUM(Sales) sales,SUM(Profit)/NULLIF(SUM(Sales),0) margin,COUNT(DISTINCT OrderID) orders FROM sales GROUP BY Region ORDER BY sales DESC;
