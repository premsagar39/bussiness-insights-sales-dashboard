"""Rebuild the embedded report snapshot from a supplied source CSV.

Close the report in Power BI first. Example:
python refresh_snapshot.py --source "Diwali Sales Data.csv" --project .
Then reopen the PBIP and select Refresh.
"""
from pathlib import Path
import argparse,base64,gzip,json
import pandas as pd

def refresh(source,project):
    project=Path(project)
    pbip=next(project.glob("*.pbip"))
    report=json.loads(pbip.read_text(encoding="utf-8-sig"))["artifacts"][0]["report"]["path"]
    stem=report.removesuffix(".Report")
    model_path=project/(stem+".SemanticModel")/"model.bim"
    model=json.loads(model_path.read_text(encoding="utf-8-sig"))
    is_superstore="Superstore" in stem
    df=pd.read_csv(source,encoding="cp1252")
    if is_superstore:
        required={"RowID","OrderID","Sales","Profit","OrderDate","ShipDate","ProductName","ProductCategory","ProductSubCategory"}
        if not required.issubset(df.columns):raise ValueError("Use the SuperStoreUS-2015 new .csv source with compact column names.")
        if df.duplicated().any():raise ValueError("Exact duplicates need review before changing the Superstore snapshot.")
        df.insert(0,"LineKey",range(1,len(df)+1))
        for c in df.select_dtypes("str"):df[c]=df[c].str.strip()
        for c in ["OrderDate","ShipDate"]:df[c]=pd.to_datetime(df[c],errors="raise").dt.strftime("%Y-%m-%d")
        if not (pd.to_datetime(df.ShipDate)>=pd.to_datetime(df.OrderDate)).all():raise ValueError("Ship dates before order dates need review.")
        names=["ProductName","ProductCategory","ProductSubCategory"]
    else:
        required={"User_ID","Product_ID","Gender","Age Group","Age","State","Zone","Occupation","Product_Category","Orders","Amount"}
        if not required.issubset(df.columns):raise ValueError("The Diwali source is missing required fields.")
        df=df.drop_duplicates().dropna(subset=["Amount"]).copy()
        for c in df.select_dtypes("str"):df[c]=df[c].str.strip()
        df.insert(0,"RecordKey",range(1,len(df)+1))
        df=df.drop(columns=["Cust_name"],errors="ignore")
        df["Age Band Order"]=df["Age Group"].map({"0-17":1,"18-25":2,"26-35":3,"36-45":4,"46-50":5,"51-55":6,"55+":7})
        if df["Age Band Order"].isna().any():raise ValueError("Review new age-group labels before updating their order.")
        names=["Product_ID","Product_Category"]
    products=df[names].drop_duplicates().reset_index(drop=True)
    products.insert(0,"ProductKey",range(1,len(products)+1))
    df=df.merge(products,on=names,validate="many_to_one")
    frames={"Sales":df,"Products":products}
    if is_superstore:
        dates=pd.DataFrame({"Date":pd.date_range(df.OrderDate.min(),df.OrderDate.max())})
        dates["Month"]=dates.Date.dt.strftime("%b")
        dates["Month Number"]=dates.Date.dt.month
        dates["Year Month"]=dates.Date.dt.strftime("%Y-%m")
        dates["Year"]=dates.Date.dt.year
        dates.Date=dates.Date.dt.strftime("%Y-%m-%d")
        frames["Dates"]=dates
    types={"dateTime":"type date","int64":"Int64.Type","double":"type number","string":"type text"}
    (project/"data").mkdir(exist_ok=True)
    for table in model["model"]["tables"]:
        name=table["name"]
        if name not in frames:continue
        frame=frames[name]
        frame.to_csv(project/"data"/(name.lower()+".csv"),index=False)
        raw=frame.to_csv(index=False).encode("utf-8")
        packed=base64.b64encode(gzip.compress(raw,mtime=0)).decode()
        pairs=', '.join('{"'+c["sourceColumn"]+'",'+types[c["dataType"]]+'}' for c in table["columns"] if "sourceColumn" in c)
        expression='let\n Source=Csv.Document(Binary.Decompress(Binary.FromText("'+packed+'",BinaryEncoding.Base64),Compression.GZip),[Delimiter=",",Encoding=65001,QuoteStyle=QuoteStyle.Csv]),\n Headers=Table.PromoteHeaders(Source,[PromoteAllScalars=true]),\n Typed=Table.TransformColumnTypes(Headers,{'+pairs+'},"en-US")\nin Typed'
        table["partitions"][0]["source"]["expression"]=expression.splitlines()
    model_path.write_text(json.dumps(model,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"Prepared {len(df):,} records. Open {pbip.name} in Power BI Desktop and select Refresh.")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description="Update a Power BI project's embedded sales snapshot.")
    parser.add_argument("--source",required=True,type=Path)
    parser.add_argument("--project",default=".",type=Path)
    args=parser.parse_args()
    refresh(args.source,args.project)

