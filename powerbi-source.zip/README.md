# Python + MySQL + Power BI source
Install requirements.txt, make MySQL 8 available, then run python src/run_pipeline.py --mysql-user root.
The command prompts for a password and loads dataset/SuperStoreUS-2015 new .csv.
It executes queries/00_schema.sql and queries/00_reporting_views.sql, then the 13 named business-analysis queries.
queries/Power bi used queries contains the three SELECT statements that supply the model.
reports/pipeline_run.json records the executed engine, source/query hashes, exported row counts and 12 reconciliation checks.
data/ contains the actual SQL-view outputs. Shipping days and discount bands are imported SQL columns.
Open Superstore_Sales_Insights.pbip, Refresh, then Save as PBIX after a rebuild.
The saved PBIX embeds the latest SQL exports; it is an import snapshot, not a live MySQL connection.
